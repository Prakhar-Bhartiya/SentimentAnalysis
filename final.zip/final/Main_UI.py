import tkinter as tk
from tkinter import *
from textblob import TextBlob
from csv import writer
from score import *
from naivebayesmain import *
#Tkinter UI
m = tk.Tk()
m.geometry("500x300")
m.configure(bg='skyblue')
m.title("Sentiment Analysis")

def main():

    username_s = username_input.get(1.0, "end-1c")
    text = tweet_input.get(1.0, "end-1c")
    blob = TextBlob(text)
    data_list = [username_s,datetime.now(),text,-1]
    addData(data_list)
    update_pred()
    res = returnScore(str(username_s))
    if res>0:
        lbl.config(text = "Not Depressed!!!!",bg='green')
    else:
        lbl.config(text = "Depressed!!!!",bg='red')

    lbl2.config(text="Result from TextBlob \n"+str(blob.sentiment)+" Result Naive History"+str(res))
    lbl3.config(text=" Result Naive History"+str(res))


def addData(d):
    with open('database.csv', 'a') as f_object:
        writer_object = writer(f_object)
        writer_object.writerow(d)
        f_object.close()


w = Label(m, text='Username',bg='skyblue')
w.pack()
username_input = Text(m,height=2, width=50)
username_input.pack()

w = Label(m, text='Tweet',bg='skyblue')
w.pack()
tweet_input = Text(m,height=2, width=50)
tweet_input.pack()


temp = tk.Label(m, text = "",bg='skyblue')
temp.pack()

button = tk.Button(m, text='POST', width=25, command=main,bg='skyblue')
button.pack()


lbl = Message(m,width=200,padx=3,bg='skyblue')
lbl.pack( )

lbl2 = tk.Label(m, text = "",bg='skyblue')
lbl2.pack()

lbl3 = tk.Label(m, text = "",bg='skyblue')
lbl3.pack()



m.mainloop()
