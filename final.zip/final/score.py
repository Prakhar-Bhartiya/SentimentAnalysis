# importing csv module
import csv
import math

#Time difference Function
from datetime import datetime

def getDuration(then, now = datetime.now(), interval = "default"):
    duration = now - then
    duration_in_s = duration.total_seconds()
    return float(duration_in_s/3600)



# csv file name
filename = "database.csv"

fields = []
rows = []
# reading csv file
with open(filename, 'r') as csvfile:
	# creating a csv reader object
	csvreader = csv.reader(csvfile)

	# extracting field names through first row
	fields = next(csvreader)

	# extracting each data row one by one
	for row in csvreader:
		rows.append(row)

# get total number of rows
# print("Total no. of rows: %d"%(csvreader.line_num))
#
# # printing the field names
# print('Field names are:' + ', '.join(field for field in fields))

def func(x):
    return -1*math.log(x+1,2)
def calalpha(x):
    # z = float(((2**x)-1)/(2**72))
    z = float((func(x)-func(72))/(func(0)-func(72)))
    return z


#2021-07-16 23:10:32.958590
def returnScore(user):
    fin_score = 0
    for col in rows:
        if col[0]==user:
            deltaT = int(getDuration(datetime.strptime(col[1],"%Y-%m-%d %H:%M:%S.%f")))
            if deltaT<=72:#72 Hrs i.e 3 Days consideration
                prediction = col[3]
                if int(prediction)==0:
                    fin_score = fin_score - calalpha(deltaT)
                else:
                    fin_score = fin_score + calalpha(deltaT)
    return fin_score

# print(returnScore("xyz"))
